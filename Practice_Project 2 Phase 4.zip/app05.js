function a() {
    var x = 2;
    function b() {
      console.log(x);
    }
    b();
  }
  
  var x = 1;
  a();