function greet(name) {
    console.log('Hello ' + name);
  }
  
  // Hoisting
  console.log(x);
  greet('vim');
  
  var x = 20;