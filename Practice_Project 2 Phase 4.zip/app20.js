var person = {
    firstname: 'Default',
    lastname: 'Default',
    getFullname: function () {
      return this.firstname + ' ' + this.lastname;
    },
  };
  
  var john = {
    firstname: 'aaa',
    lastname: 'bb',
  };
  
 
  // to create objects in javascript
  
  var johnc = Object.create(person);
  johnc.firstname = 'xyz';
  johnc.lastname = 'zyx';
  console.log(johnc.getFullname());
  console.log(johnc);