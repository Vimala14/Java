var a=2;
b=3;
c=4;
a=b=c;
console.log(a);//4
console.log(b);//4
console.log(c);//4