console.log(a);

var a = 'hello world';

console.log(a);

function b() {
  console.log('called function b');
}

b();