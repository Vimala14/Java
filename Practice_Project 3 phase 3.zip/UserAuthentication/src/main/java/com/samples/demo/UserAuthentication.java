package com.samples.demo;

public class UserAuthentication {
	public String username()
	{
		String email = "xyz@gmail.com";
		return email;
	}
	
	public String paswd()
	{
		String password = "xyz";
		return password;
	}
	
	

}
