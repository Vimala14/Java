package com.basic;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class SelIntro {
	
	public static void main(String[] args) {
		
		WebDriver webdriver = null;
		
		System.setProperty("webdriver.chrome.driver", "C:\\tools\\chromedriver_win32\\chromedriver.exe");
		webdriver = new ChromeDriver();
		
	//	System.setProperty("webdriver.gecko.driver", "C:\\tools\\geckodriver-v0.31.0-win64\\geckodriver.exe");
	//	webdriver = new FirefoxDriver();
		
	//	System.setProperty("webdriver.edge.driver", "C:\\tools\\edgedriver_win64\\msedgedriver.exe");
	//	webdriver = new EdgeDriver();
		
		webdriver.get("http://localhost:4200");
		System.out.println(webdriver.getTitle());
		System.out.println(webdriver.getCurrentUrl());
		
		webdriver.findElement(By.id("accounts1")).click();
		//webdriver.quit();
	}

}