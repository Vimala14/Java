package com.basic;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login
{
	public static void main(String[] args)
	{
		
		System.setProperty("webdriver.chrome.driver", "C:\\tools\\chromedriver_win32 (1)\\chromedriver.exe");
		WebDriver d=new ChromeDriver();
		d.get("https://www.shine.com/login/");
		d.findElement(By.id("id_email_login")).sendKeys("vimala2k@gmail.com");
		d.findElement(By.id("id_password")).sendKeys("Vim@12345");
		d.findElement(By.xpath("//*[@id=\"cndidate_login_widget\"]/form/ul[2]/li[4]/div/button")).click();
		
				
	}
}