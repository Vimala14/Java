package com.basic;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Registration
{
	public static void main(String[] args)
	{
		
		System.setProperty("webdriver.chrome.driver", "C:\\tools\\chromedriver_win32 (1)\\chromedriver.exe");
		WebDriver d=new ChromeDriver();
		d.get("https://www.shine.com/registration/");
		d.findElement(By.id("id_name")).sendKeys("vimala");
		d.findElement(By.id("id_email")).sendKeys("vimala2k@gmail.com");
		d.findElement(By.id("id_cell_phone")).sendKeys("9876512340");
		d.findElement(By.id("id_password")).sendKeys("Vim@12345");
		d.findElement(By.id("registerButton")).click();
		
	}
}