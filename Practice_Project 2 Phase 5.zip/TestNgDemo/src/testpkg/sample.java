package testpkg;

import org.testng.annotations.Test;

public class sample {

	@Test
	public void demo() {
		System.out.println("hello");
	}
	
}