package testpkg;

import org.testng.annotations.Test;

public class sample2 {

	@Test
	public void demo2() {
		System.out.println("running demo2");
	}
}