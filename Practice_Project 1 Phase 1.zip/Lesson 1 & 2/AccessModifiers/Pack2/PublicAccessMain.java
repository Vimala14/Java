package Pack2;
import Pack1.*;

public class PublicAccessMain {

	public static void main(String[] args) {
		
		PublicAccessSpecifier obj = new PublicAccessSpecifier(); 
        obj.display();  
		
	}
}
