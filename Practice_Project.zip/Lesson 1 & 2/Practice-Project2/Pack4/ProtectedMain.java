package Pack4;

import Pack3.*;

public class ProtectedMain extends Protected {

		public static void main(String[] args) {
			ProtectedMain obj = new ProtectedMain ();   
		       obj.display();  
		}

	}




