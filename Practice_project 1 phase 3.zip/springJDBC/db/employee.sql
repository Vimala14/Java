use mydb;

create table employeelist(id int, firstname varchar(20), lastname varchar(20));

select * from employeelist;