package springmvcorm.service;

import java.util.List;

import springmvcorm.entity.User;

public interface UserService {

	int save(User user);
	
	List<User> getUsers();
	
}