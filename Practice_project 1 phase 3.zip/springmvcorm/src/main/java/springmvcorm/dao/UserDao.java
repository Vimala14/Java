package springmvcorm.dao;

import java.util.List;

import springmvcorm.entity.User;

public interface UserDao {

	int create(User user);
	
	List<User> findUsers();
	
}