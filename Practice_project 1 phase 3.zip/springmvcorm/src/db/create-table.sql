use mydb;

create table user(id int, name varchar(255), email varchar(255));
