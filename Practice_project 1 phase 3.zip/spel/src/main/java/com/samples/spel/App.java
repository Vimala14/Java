package com.samples.spel;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.samples.spel.model.CarDealer;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		// create the spring container
		ClassPathXmlApplicationContext springContainer = new ClassPathXmlApplicationContext(
				"com/samples/spel/SpringConfig.xml");

		CarDealer dealer = (CarDealer) springContainer.getBean("carDealer");
		System.out.println(dealer);

	}
}