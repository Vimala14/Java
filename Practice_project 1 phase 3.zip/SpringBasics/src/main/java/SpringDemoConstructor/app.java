package SpringDemoConstructor;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class app {
	public static void main(String[] args) {

		// create the spring container
		ClassPathXmlApplicationContext springContainer = new ClassPathXmlApplicationContext("SpringDemoConstructor/Spring.xml");

		Employee emp1 = (Employee) springContainer.getBean("emp");
		System.out.println(emp1);
		
	}
}