package PropertyFile;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class app {

	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("PropertyFIle/Spring.xml");
		MyDAO dao = (MyDAO) context.getBean("dao");
		System.out.println(dao);
		
	}

}