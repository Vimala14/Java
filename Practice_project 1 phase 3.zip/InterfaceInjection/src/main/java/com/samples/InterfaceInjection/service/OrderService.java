package com.samples.InterfaceInjection.service;

public interface OrderService {

	void placeOrder();
	
}