package com.samples.InterfaceInjection.DAO.impl;

import org.springframework.stereotype.Component;

import com.samples.InterfaceInjection.DAO.OrderDAO;

@Component("daov2")
public class OrderDAOImplv2 implements OrderDAO{

	@Override
	public void createOrder() {
		System.out.println("create order in Oracle DB");
	}

}